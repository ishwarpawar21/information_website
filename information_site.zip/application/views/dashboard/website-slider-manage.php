 <style>
.btn-circle {
  width: 30px;
  height: 30px;
  padding: 6px 0;
  border-radius: 15px;
  text-align: center;
  font-size: 12px;
  line-height: 1.428571429;
}

 </style> 
    
	<div class="col-sm-9 col-sm-offset-3 col-lg-10 col-lg-offset-2 main">			
		<div class="row">
			<ol class="breadcrumb">
				<li><a href="#"><span class="glyphicon glyphicon-home"></span></a></li>
				<li class="active">Website Slider</li>
				<li class="active">Manage Slider</li>
			</ol>
		</div><!--/.row-->
		
		 
		
<div class="row" style="margin-top: 10px">
		
		<div class="col-lg-12">
<?php
if($this->session->userdata('error_msg'))
{
?>
			<div class="alert bg-<?=$this->session->userdata('error_cls')?>" role="alert" style="margin-top: 10px">
				<span class="glyphicon glyphicon-check"></span> 
				<?=$this->session->userdata('error_msg')?>					
			</div>
<?php	
		$this->session->unset_userdata('error_msg');
		$this->session->unset_userdata('error_cls');
}			
?>

			<div class="panel panel-primary">
					<div class="panel-heading">Website Slider</div>
					<div class="panel-body">
						
						<form class="form-horizontal" method="POST" >
						 		 <div class="form-group">
									<label class="col-md-3 control-label" for="headings">New Heading </label>
									<div class="col-md-9">
										<input id="headings" name="headings" type="text" placeholder="Heading" class="form-control">
									</div>
								</div>
											
								<div class="form-group">
									<label class="col-md-3 control-label" for="descriptions">New Description</label>
									<div class="col-md-9">
										<textarea id="descriptions" name="descriptions" placeholder="Description" class="form-control"></textarea>
									</div>
								</div>
								
								<div class="form-group">
									<label class="col-md-3 control-label" for="name"></label>
									<div class="col-md-9">
										<button type="submit" name="btn_add_slider" class="btn btn-primary">
											<i class="glyphicon glyphicon-ok"></i> 
											Add New Slider Information
										</button>
									</div>
								</div>
						 </form>
					 
					</div>
				</div>
		</div>
			<div class="col-lg-12">
 
				<div class="panel panel-default">
					<div class="panel-heading">
						Manage Website Pages
						 
					</div>
					<div class="panel-body">
						<table data-toggle="table" data-url="tables/data1.json"  data-show-refresh="true" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="asc">
						    <thead>
						    <tr>
						        <th data-field="state" data-checkbox="false" width="50" >Sr No</th>
						        <th data-field="Headings" data-sortable="true">Headings</th>
						        <th data-field="Description"  data-sortable="true">Description</th>
						        <th data-field="Status" data-sortable="true">Status</th>
						        <th data-field="Action" data-sortable="true">Action</th>
						    </tr>
						    </thead>
						    <tbody>

<?php
	$cnt=1;
	$result=$this->db->query("select * from tbl_website_slider ");
	if($result->result() > 0)
	{
		foreach($result->result() as $row)
		{
?>
		<tr>
						    		<td><?=$cnt?></td>
						    		<td><?=$row->headings?></td>
						    		<td>
							    		 <?=$row->descriptions?>
							    	</td>
							    	<td>
<style>
	.label1
	{
		background:#8ad919;
		padding: 3px 5px;
    border-radius: 2px;
    cursor: pointer;
    font-weight: 600;
    display: inline-block;
    margin: 0 5px 5px 0;
    color: #fff;
	}
	
	.label2
	{
		background:#f56954;
		padding: 3px 5px;
	    border-radius: 2px;
	    cursor: pointer;
	    font-weight: 600;
	    display: inline-block;
	    margin: 0 5px 5px 0;
	    color: #fff;
	}
</style>							    	
							    			<?php 
												if($row->status=='1')
							    					{
														echo '<div class="label1" style="position: relative;">Published</div>';
														
													}
													else
													{
														echo '<div class="label2" style="position: relative;">Unpublished</div>';	
													}
							    			?>
							    	</td>
						    		<td>
						    		
							    		<a href="<?=base_url()?>dashboard/webside_slider_update?id=<?=base64_encode($row->id)?>" style="text-decoration: none">
							    			<button type="button" class="btn btn-primary btn-circle" title="Modify Page">
							    				<i class="glyphicon glyphicon-check"></i>
							    			</button>
							    		</a>
							    		
							    		<a href="<?=base_url()?>dashboard/website_slider?ch=del&id=<?=base64_encode($row->id)?>" style="text-decoration: none">	
							    			<button type="button" class="btn btn-danger btn-circle " title="Delete Slide">
							    				<i class="glyphicon glyphicon-remove"></i>
							    			</button>
	                            		</a>
	                            		
<?php
	if($row->status=='1')
	{
		
	
?>	                            		
	                            		<a href="<?=base_url()?>dashboard/website_slider?ch=down&id=<?=base64_encode($row->id)?>" style="text-decoration: none">	
							    			<button type="button" class="btn btn-danger btn-circle " title="Unpublish this.">
							    				<i class="glyphicon glyphicon-thumbs-down"></i>
							    			</button>
	                            		</a>
<?php
	}
	else
	{
?>
										<a href="<?=base_url()?>dashboard/website_slider?ch=up&id=<?=base64_encode($row->id)?>" style="text-decoration: none">	
							    			<button type="button" class="btn btn-info btn-circle" style="background: #8ad919;border-color:#8ad919 " title="Publish this.">
							    				<i class="glyphicon glyphicon-thumbs-up"></i>
							    			</button>
	                            		</a>

<?php		
	}
?>	       
	                            		
						    		</td>
		</tr>		
<?php			
		$cnt++;}
	}
?>						    
						    
						    </tbody>
						</table>
					</div>
				</div>
			</div>
		</div><!--/.row-->	
	 </div><!--/.main-->

 