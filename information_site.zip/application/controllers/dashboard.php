<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller
{
	public function __construct() 
	{
		parent::__construct();
		$this->load->library('session');
		$this->load->library('form_validation');
		$this->load->model('common_model');
		$this->check_login();
		$this->load->library('upload');
		$this->website_name="Information Website ";
	}
	
	public function index()
	{
		$this->wd();
	}
	
	public function check_login()
	{
		if($this->session->userdata('is_logged_in')!='1')
		{
			$this->session->set_userdata('error_msg',"Please Enter your username and password.");
			redirect(base_url().'login/d_login');
		}
	}
	
	public function calender_display()
	{
		$this->load->view('dashboard/calender');
	}
	public function wd()
	{
		$data['page_header']="Dashboard | " . $this->website_name;
		$data['Website_name']=$this->website_name;
		$data['page']='content';
		$this->load->view('dashboard/template',$data);
	}
	
	function account_details()
	{
		if(isset($_POST['btn_update_account']))
		{
			$this->form_validation->set_rules('f_name','First Name','required|xss_clean');
			$this->form_validation->set_rules('l_name','Last Name','required|xss_clean');
			$this->form_validation->set_rules('address','Address','required|xss_clean');
			$this->form_validation->set_rules('phno','Phone No','required|xss_clean');
			
			
			if($this->form_validation->run())
			{
				$data_array=array(
					'f_name'=>$_POST['f_name'],
					'l_name'=>$_POST['l_name'],
					'address'=>$_POST['address'],
					'phno'=>$_POST['phno'],
					'profile_pic'=>'account_pic.jpg',
				);
				
					
				$config=array('upload_path' => 'assets/dashboard/uploads/', 'allowed_types' => 'jpg', 'file_name'=>'account_pic.jpg', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("profile_pic");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$config["source_image"] = 'assets/dashboard/uploads/account_pic.jpg';
					$config['new_image'] = 'assets/dashboard/uploads/account_pic.jpg';
					$config["width"] = 100;
					$config["height"] = 100;

					$this->load->library('image_lib', $config);
					$this->image_lib->fit();
				}
				
				
				
			$result=$this->common_model->update_records('tbl_admin',$data_array,'username',$this->session->userdata('Ausername'));
				if($result)
				{ 
				  $this->session->set_userdata('error_msg','Account details Updated...');
				  $this->session->set_userdata('error_cls','success');
				 }
				else
				{ 
				  $this->session->set_userdata('error_msg','Error Occurred, Try again...');
				  $this->session->set_userdata('error_cls','danger'); 
				}
				
				redirect(base_url().'dashboard/account_details/');
			}
			
		}
		$data['page_header']="Account Details | " . $this->website_name;
		$data['Website_name']=$this->website_name;
		$data['page']='admin-account';
		$this->load->view('dashboard/template',$data);
	}
	
	public function account_settings()
	{
		if(isset($_POST['btn_password']))
		{
			$this->form_validation->set_rules('password','Old Password','required|xss_clean|trim');
			$this->form_validation->set_rules('Npassword','New Password','min_length[4]|max_length[10]|required|xss_clean|trim');
			$this->form_validation->set_rules('Cpassword','Confirm Password','matches[Npassword]|required|xss_clean|trim');
			if($this->form_validation->run())
			{
				if(($_POST['password'])!=$this->session->userdata('Apassword'))
				{
					$this->session->set_userdata('error_msg','Please enter correct previous password');
					$this->session->set_userdata('error_cls','danger');
				}
				else
				{
					$data_field=array(
						'password'=>md5($_POST['Npassword']),
					);
					$result=$this->common_model->update_records('tbl_admin',$data_field,'username',$this->session->userdata('Ausername'));
					if($result)
					{
						$this->session->set_userdata('Apassword',$_POST['Npassword']);
						$this->session->set_userdata('admin_logged_in','1');
					
						$this->session->set_userdata('error_msg','Account Password Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
				}
					redirect(base_url().'dashboard/account_settings');
			}
			
		}
		$data['page_header']="Account Settings | " . $this->website_name;
		$data['Website_name']=$this->website_name;
		$data['page']='admin-settings';
		$this->load->view('dashboard/template',$data);
	}
	
	
	public function website_pages()
	{
		$data['page_header']="Account Settings | " . $this->website_name;
		$data['Website_name']=$this->website_name;
			
		if(isset($_GET['pg']))
		{
			if(isset($_POST['btn_create_page']))
			{
				$this->form_validation->set_rules('menu_name','Menu Name','required|xss_clean');
				$this->form_validation->set_rules('page_title','Page Title','required|xss_clean');
				$this->form_validation->set_rules('page_position','Page Position','required|xss_clean');
				$this->form_validation->set_rules('page_content','Page Content','required|xss_clean');
				
				if($this->form_validation->run())
				{
					
					$max_id=$this->common_model->search_maxid('tbl_website_pages');
					$data_field=array(
						'id'=>$max_id,
						'menu_name'=>$_POST['menu_name'],
						'page_title'=>$_POST['page_title'],
						'page_position'=>$_POST['page_position'],
						'page_content'=>$_POST['page_content']
					);
					$q=$this->common_model->insert_records('tbl_website_pages',$data_field);
					if($q)
					{
					  	$this->session->set_userdata('error_msg','New Page Created Successfully...');
						$this->session->set_userdata('error_cls','success');
						redirect(base_url().'dashboard/website_pages/');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
						redirect(base_url().'dashboard/website_pages?pg='.base64_encode('website-pages-create'));
					}
				}
				
				
			}
			else
			if(isset($_POST['btn_edit_page']))
			{
				$this->form_validation->set_rules('menu_name','Menu Name','required|xss_clean');
				$this->form_validation->set_rules('page_title','Page Title','required|xss_clean');
				$this->form_validation->set_rules('page_position','Page Position','required|xss_clean');
				$this->form_validation->set_rules('page_content','Page Content','required|xss_clean');
				
				if($this->form_validation->run())
				{
					$data_field=array(						
						'menu_name'=>$_POST['menu_name'],
						'page_title'=>$_POST['page_title'],
						'page_position'=>$_POST['page_position'],
						'page_content'=>$_POST['page_content']
					);
					$q=$this->common_model->update_records('tbl_website_pages',$data_field,'id',base64_decode($_POST['id']));
					if($q)
					{
						$this->session->set_userdata('error_msg','Webpage Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
						redirect(base_url().'dashboard/website_pages/');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
						redirect(base_url().'dashboard/website_pages?pg='.base64_encode('website-pages-create'));
					}
				}
			}
			else
			
			
			$data['page']=base64_decode($_GET['pg']);
			$this->load->view('dashboard/template',$data);
		}
		else
		 if(isset($_GET['ch']))
			{
					if($_GET['ch']=='down')
				{
				$stat=$this->common_model->updateStatus('tbl_website_pages',base64_decode($_GET['id']),'0');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Page has been unpublished Sucessfully..');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/website_pages');
			}
			else
			if($_GET['ch']=='up')
			{
				$stat=$this->common_model->updateStatus('tbl_website_pages',base64_decode($_GET['id']),'1');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Page has been published Sucessfully..');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/website_pages');
			}
			
			else{
		
				$q=$this->common_model->deleteRecords('tbl_website_pages',base64_decode($_GET['id']));
				if($q)
					{
						$this->session->set_userdata('error_msg','Webpage deleted Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
				redirect(base_url().'dashboard/website_pages/');
			}
				redirect(base_url().'dashboard/website_pages/');
		 }
		else
		{
			$data['page']='website-pages-manage';
			$this->load->view('dashboard/template',$data);
		}
	}
	
	public function contact_details()
	{
		if(isset($_POST['btn_update_contact']))
		{
			$this->form_validation->set_rules('email_id','Email Id','required|xss_clean');
			$this->form_validation->set_rules('phone_no','Phone No','required|xss_clean');
			$this->form_validation->set_rules('address','Address','required|xss_clean');
			if($this->form_validation->run())
			{
				$data_field=array(
					'email_id'=>$_POST['email_id'],
					'phone_no'=>$_POST['phone_no'],
					'fax_no'=>$_POST['fax_no'],
					'address'=>$_POST['address']			
				);
				$result=$this->common_model->update_records('tbl_contact_details',$data_field,'id','1');
				if($result)
					{
						$this->session->set_userdata('error_msg','Contact Details Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/contact_details/');
			}
			
		}
		$data['page_header']="Contact Details | " . $this->website_name;
		$data['Website_name']=$this->website_name;
		$data['page']='contact-details';
		$this->load->view('dashboard/template',$data);
		
	}
	
	public function website_settings()
	{
		if(isset($_POST['btn_update_logo']))
		{				
				$config=array('upload_path' => 'assets/dashboard/uploads/', 'allowed_types' => 'png', 'file_name'=>'logo.png', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("website_logo");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$config["source_image"] = 'assets/dashboard/uploads/logo.png';
					$config['new_image'] = 'assets/dashboard/uploads/logo.png';
					$config["width"] = 200;
					$config["height"] = 50;

					$this->load->library('image_lib', $config);
					$this->image_lib->fit();
					
					$data_field=array('logo'=>$datas['file_name']);
					
					$this->common_model->update_records('tbl_website_settings',$data_field,'id','1');
					$this->session->set_userdata('error_msg','Website Logo Updated Sucessfully..');
					$this->session->set_userdata('error_cls','success');
					
				}
				else
				{
					$this->session->set_userdata('error_msg','Unable to upload, Select proper image.');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/website_settings/');
		}else
		if(isset($_POST['btn_update_details']))
		{
			$this->form_validation->set_rules('website_title','Website Title','required|xss_clean');
			$this->form_validation->set_rules('keywords','Meta Keywords','required|xss_clean');
			$this->form_validation->set_rules('description','Website Description','required|xss_clean');
		
			
			if($this->form_validation->run())
			{
				$data_field=array('website_title'=>$_POST['website_title'],'keywords'=>$_POST['keywords'],'description'=>$_POST['description']);
					
					$q=$this->common_model->update_records('tbl_website_settings',$data_field,'id','1');
					if($q)
					{
						$this->session->set_userdata('error_msg','Website Details Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Unable to upload, Select proper image.');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/website_settings/');
					
			}
			
		}
		else
		if(isset($_POST['btn_update_logo_position']))
		{
			$this->form_validation->set_rules('logo_position','Logo Position','required');
			
			if($this->form_validation->run())
			{
				$data_field=array('logo_position'=>$_POST['logo_position']);
					
					$q=$this->common_model->update_records('tbl_website_settings',$data_field,'id','1');
					if($q)
					{
						$this->session->set_userdata('error_msg','Logo Position Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/website_settings/');
			}
		}else
		if(isset($_POST['btn_update_social_link']))
		{ 
				$data_field=array(
					'facebook'=>$_POST['facebook'],
					'twitter'=>$_POST['twitter'],
					'google_plus'=>$_POST['google_plus'],
					'youtube'=>$_POST['youtube'],
					'linkedin'=>$_POST['linkedin']
				);
					
					$q=$this->common_model->update_records('tbl_website_settings',$data_field,'id','1');
					if($q)
					{
						$this->session->set_userdata('error_msg','Website Social Links Are Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
						redirect(base_url().'dashboard/website_settings/');
					
		}
		else
		if(isset($_POST['btn_update_api']))
		{
			 
				$data_field=array('payment_api'=>$_POST['payment_api']);
					
					$q=$this->common_model->update_records('tbl_website_settings',$data_field,'id','1');
					if($q)
					{
						$this->session->set_userdata('error_msg','Apyment Api Key Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
						redirect(base_url().'dashboard/website_settings/');
					
		
		}
		else
		if(isset($_POST['btn_update_emails']))
		{
			$data_field=array('for_contact_page'=>$_POST['for_contact_page'],'for_newsletter_page'=>$_POST['for_newsletter_page'],'for_support'=>$_POST['for_support']);
					
					$q=$this->common_model->update_records('tbl_website_settings',$data_field,'id','1');
					if($q)
					{
						$this->session->set_userdata('error_msg','Website Emaild Ids Are Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/website_settings/');
		
		}
		$data['page_header']="Website Settings | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='website-settings';
		$this->load->view('dashboard/template',$data);
	}
	
	public function website_slider()
	{		
		$data['page_header']="Website Slider | " . $this->website_name;
		$data['Website_name']=$this->website_name;
		 	
		if(isset($_GET['ch']))
		{
			if($_GET['ch']=='down')
			{
				$stat=$this->common_model->updateStatus('tbl_website_slider',base64_decode($_GET['id']),'0');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Slide has been unpublished Sucessfully..');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/website_slider');
			}
			else
			if($_GET['ch']=='up')
			{
				$stat=$this->common_model->updateStatus('tbl_website_slider',base64_decode($_GET['id']),'1');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Slide has been published Sucessfully..');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/website_slider');
			}
			else
			{
				$q=$this->common_model->deleteRecords('tbl_website_slider',base64_decode($_GET['id']));
				if($q)
					{
						$this->session->set_userdata('error_msg','Website Slide deleted Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
				redirect(base_url().'dashboard/website_slider/');
			}
			}else
			if(isset($_POST['btn_add_slider']))
			{ 
				$this->form_validation->set_rules('headings','Page Title','required|xss_clean');
				$this->form_validation->set_rules('descriptions','Page Position','required|xss_clean');
				
				if($this->form_validation->run())
				{					
					$max_id=$this->common_model->search_maxid('tbl_website_slider');
					$data_field=array(
						'id'=>$max_id,
						'headings'=>$_POST['headings'],
						'descriptions'=>$_POST['descriptions']
					);
					
					$q=$this->common_model->insert_records('tbl_website_slider',$data_field);
					if($q)
					{
					  	$this->session->set_userdata('error_msg','New Slider Created Successfully...');
						$this->session->set_userdata('error_cls','success');
						redirect(base_url().'dashboard/website_slider/');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
						redirect(base_url().'dashboard/website_slider');
					}
				}
			}
			 
			  
			
			$data['page']='website-slider-manage';
			$this->load->view('dashboard/template',$data);
   }
   
   public function webside_slider_update()
   {
   			$data['page_header']="Website Slider | " . $this->website_name;
			$data['Website_name']=$this->website_name;
			
			if(isset($_POST['btn_edit_slide']))
			{
				$this->form_validation->set_rules('headings','Page Title','required|xss_clean');
				$this->form_validation->set_rules('descriptions','Page Position','required|xss_clean');
				
				if($this->form_validation->run())
				{
					$data_field=array(						
						'headings'=>$_POST['headings'],
						'descriptions'=>$_POST['descriptions']
					);
					$q=$this->common_model->update_records('tbl_website_slider',$data_field,'id',base64_decode($_POST['id']));
					if($q)
					{
						$this->session->set_userdata('error_msg','Webpage Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
						redirect(base_url().'dashboard/website_slider/');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
						redirect(base_url().'dashboard/website_pages?id='.base64_encode('website-pages-create'));
					}
				}
			}
			
   			$data['page']='website-slider-edit';
			$this->load->view('dashboard/template',$data);
   }
   
   public function home_page()
   {
   			$data['page_header']="Website Home Page Settings | " . $this->website_name;
			$data['Website_name']=$this->website_name;
			$data['page']='home-page-manage';
			
			if(isset($_GET['pg']))
			{
				$data['page']=base64_decode($_GET['pg']);
			}
			else
			if(isset($_GET['ch']))
			{
				if($_GET['ch']=='del_lowwer')
					{
						
						$result=$this->common_model->deleteRecords('tbl_lower_infobox',base64_decode($_GET['id']));
						if($result)
								{
									$this->session->set_userdata('error_msg','Lower Infobox Removed Sucessfully..');
									$this->session->set_userdata('error_cls','success');
								}
								else
								{
									$this->session->set_userdata('error_msg','Error Occurred Try again...');
									$this->session->set_userdata('error_cls','danger');
								}
								redirect(base_url().'dashboard/home_page/');
					
					}
					else
				if($_GET['ch']=='del_upper')
					{
						$result=$this->common_model->deleteRecords('tbl_info_box',base64_decode($_GET['id']));
						if($result)
								{
									$this->session->set_userdata('error_msg','Upper Infobox Removed Sucessfully..');
									$this->session->set_userdata('error_cls','success');
								}
								else
								{
									$this->session->set_userdata('error_msg','Error Occurred Try again...');
									$this->session->set_userdata('error_cls','danger');
								}
								redirect(base_url().'dashboard/home_page/');
					}
					else
					if($_GET['ch']=='down')
					{
						$stat=$this->common_model->updateStatus('tbl_lower_infobox',base64_decode($_GET['id']),'0');
						if($stat)
						{
							$this->session->set_userdata('error_msg','Infobox has been unpublished Sucessfully..');
							$this->session->set_userdata('error_cls','success');
						}
						else
						{
							$this->session->set_userdata('error_msg','Error occurred, Try again');
							$this->session->set_userdata('error_cls','danger');
						}
						redirect(base_url().'dashboard/home_page');
					}
					else
					if($_GET['ch']=='up')
					{
						$stat=$this->common_model->updateStatus('tbl_lower_infobox',base64_decode($_GET['id']),'1');
						if($stat)
						{
							$this->session->set_userdata('error_msg','Infobox has been published Sucessfully..');
							$this->session->set_userdata('error_cls','success');
						}
						else
						{
							$this->session->set_userdata('error_msg','Error occurred, Try again');
							$this->session->set_userdata('error_cls','danger');
						}
						redirect(base_url().'dashboard/home_page');
					}
					else
					if($_GET['ch']=='down1')
					{
						$stat=$this->common_model->updateStatus('tbl_info_box',base64_decode($_GET['id']),'0');
						if($stat)
						{
							$this->session->set_userdata('error_msg','Infobox has been unpublished Sucessfully..');
							$this->session->set_userdata('error_cls','success');
						}
						else
						{
							$this->session->set_userdata('error_msg','Error occurred, Try again');
							$this->session->set_userdata('error_cls','danger');
						}
						redirect(base_url().'dashboard/home_page');
					}
					else
					if($_GET['ch']=='up1')
					{
						$stat=$this->common_model->updateStatus('tbl_info_box',base64_decode($_GET['id']),'1');
						if($stat)
						{
							$this->session->set_userdata('error_msg','Infobox has been published Sucessfully..');
							$this->session->set_userdata('error_cls','success');
						}
						else
						{
							$this->session->set_userdata('error_msg','Error occurred, Try again');
							$this->session->set_userdata('error_cls','danger');
						}
						redirect(base_url().'dashboard/home_page');
					}
			 }
			if(isset($_POST['btn_update_banner']))
			{						
				$config=array('upload_path' => 'assets/dashboard/uploads/', 'allowed_types' => 'jpg', 'file_name'=>'banner.jpg', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("website_banner");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$this->session->set_userdata('error_msg','Website Banner Updated Sucessfully..');
					$this->session->set_userdata('error_cls','success');
					
				}
				else
				{
					$this->session->set_userdata('error_msg','Unable to upload, Select proper image.');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/home_page/');
		
			}
			else
		if(isset($_POST['btn_update_banner_position']))
		{
			$this->form_validation->set_rules('banner_position','Banner Position','required');
			
			if($this->form_validation->run())
			{
				$data_field=array('banner_position'=>$_POST['banner_position']);
					
					$q=$this->common_model->update_records('tbl_home_page_settings',$data_field,'id','1');
					if($q)
					{
						$this->session->set_userdata('error_msg','Logo Position Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/home_page/');
			}
		
		}
		else
		if(isset($_POST['btn_add_infobox']))
		{ 	
			$this->form_validation->set_rules('headings','Heading','required|xss_clean');
			$this->form_validation->set_rules('short_description','Short Description','required|xss_clean');
			
			if($this->form_validation->run())
			{
				$config=array('upload_path' => 'assets/dashboard/uploads/info_box', 'allowed_types' => 'jpg', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("info_image");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$config["source_image"] = 'assets/dashboard/uploads/info_box/'.$datas['file_name'];
					$config['new_image'] = 'assets/dashboard/uploads/info_box/'.$datas['file_name'];
					$config["width"] = 320;
					$config["height"] = 320;

					$this->load->library('image_lib', $config);
					$this->image_lib->fit();
			  
						$data_field=array(
							'image_name'=>$datas['file_name'],
							'headings'=>$_POST['headings'],
							'meta_keywords'=>$_POST['meta_keywords'],
							'short_description'=>$_POST['short_description']
							);
						$this->common_model->insert_records('tbl_info_box',$data_field);
					 
						
						$this->session->set_userdata('error_msg','Product Image Uploaded Sucessfully..');
						$this->session->set_userdata('error_cls','success');
						
					}
					else
					{
						$this->session->set_userdata('error_msg','Unable to upload, Select proper image.');
						$this->session->set_userdata('error_cls','danger');
						
					}
					redirect(base_url().'dashboard/home_page/');
		
			}
		}
		
		else
		if(isset($_POST['btn_update_infobox']))
		{		
			$this->form_validation->set_rules('headings','Heading','required|xss_clean');
			$this->form_validation->set_rules('short_description','Short Description','required|xss_clean');
			
			if($this->form_validation->run())
			{
				$config=array('upload_path' => 'assets/dashboard/uploads/info_box', 'allowed_types' => 'jpg', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("info_image");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$config["source_image"] = 'assets/dashboard/uploads/info_box/'.$datas['file_name'];
					$config['new_image'] = 'assets/dashboard/uploads/info_box/'.$datas['file_name'];
					$config["width"] = 320;
					$config["height"] = 320;

					$this->load->library('image_lib', $config);
					$this->image_lib->fit();
			  
						$data_field=array(
							'image_name'=>$datas['file_name'],
							'headings'=>$_POST['headings'],
							'meta_keywords'=>$_POST['meta_keywords'],
							'short_description'=>$_POST['short_description']
							);
						$this->common_model->update_records('tbl_info_box',$data_field,'id',base64_decode($_POST['id']));
						
						$this->session->set_userdata('error_msg','Info box Uploaded Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/home_page/');
			}
		}
		else
		if(isset($_POST['btn_update_lower_infobox']))
		{		
			$this->form_validation->set_rules('headings','Heading','required|xss_clean');
			$this->form_validation->set_rules('short_description','Short Description','required|xss_clean');
			
			if($this->form_validation->run())
			{
				 
						$data_field=array(
						 	'headings'=>$_POST['headings'],
							'short_descriptions'=>$_POST['short_description']
							);
						$ins=$this->common_model->update_records('tbl_lower_infobox',$data_field,'id',base64_decode($_POST['id']));
					if($ins)	
					{
						$this->session->set_userdata('error_msg','Lower Info box Uploaded Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/home_page/');
			}
			
		}
		else
		if(isset($_POST['btn_update_lower_tile']))
		{
			$this->form_validation->set_rules('lower_title','Lower Infobox Title','required|xss_clean');
			$this->form_validation->set_rules('lowerinfo_background_color','Lower Infobox Color','required|xss_clean');
			if($this->form_validation->run())
			{
				$data_field=array( 'lower_title'=>$_POST['lower_title'], 'lowerinfo_background_color'=>$_POST['lowerinfo_background_color'] );
				$stat=$this->common_model->update_records('tbl_home_page_settings',$data_field,'id','1');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Info box Title Uploaded Sucessfully..');
					$this->session->set_userdata('error_cls','success');	
				}
				else
				{
					$this->session->set_userdata('error_msg','Error Occurred Try again...');
					$this->session->set_userdata('error_cls','danger');
					
				}
				
			redirect(base_url().'dashboard/home_page/');
			}
		}
		else
		if(isset($_POST['btn_add_lower_infobox']))
		{
			$this->form_validation->set_rules('headings','Lower Infobox headings','required|xss_clean');
			$this->form_validation->set_rules('short_description','Lower Short Descriptions ','required|xss_clean');
			if($this->form_validation->run())
			{
				$data_field=array( 'headings'=>$_POST['headings'],'short_descriptions'=>$_POST['short_description'], );
				$stat=$this->common_model->insert_records('tbl_lower_infobox',$data_field);
				if($stat)
				{
					$this->session->set_userdata('error_msg','Lower Info box added Sucessfully..');
					$this->session->set_userdata('error_cls','success');	
				}
				else
				{
					$this->session->set_userdata('error_msg','Error Occurred Try again...');
					$this->session->set_userdata('error_cls','danger');
					
				}
				
			redirect(base_url().'dashboard/home_page/');
			}
		}
		else
		if(isset($_POST['btn_update_container']))
		{
			$this->form_validation->set_rules('bottom_container_heads','Container headings','required|xss_clean');
			$this->form_validation->set_rules('bottom_container_desc','Container Descriptions ','required|xss_clean');
			if($this->form_validation->run())
			{
				$data_field=array( 'bottom_container_heads'=>$_POST['bottom_container_heads'],'bottom_container_desc'=>base64_encode($_POST['bottom_container_desc']) );
				$stat=$this->common_model->update_records('tbl_home_page_settings',$data_field,'id','1');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Container Updated Sucessfully..');
					$this->session->set_userdata('error_cls','success');	
				}
				else
				{
					$this->session->set_userdata('error_msg','Error Occurred Try again...');
					$this->session->set_userdata('error_cls','danger');
					
				}
				
			redirect(base_url().'dashboard/home_page/');
			}
		}
		
		else
		if(isset($_POST['btn_set_menu_background_color']))
		{
			$this->form_validation->set_rules('menu_background_color','Colour','required|xss_clean');
			
			if($this->form_validation->run())
			{
				$data_field=array( 'menu_background_color'=>$_POST['menu_background_color']);
				$stat=$this->common_model->update_records('tbl_home_page_settings ',$data_field,'id','1');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Colour Updated Sucessfully..');
					$this->session->set_userdata('error_cls','success');	
				}
				else
				{
					$this->session->set_userdata('error_msg','Error Occurred Try again...');
					$this->session->set_userdata('error_cls','danger');
					
				}
				
			redirect(base_url().'dashboard/home_page/');
			}
		}
		
		else
		if(isset($_POST['btn_set_menu_hover_color']))
		{
			$this->form_validation->set_rules('menu_hover_color','Colour','required|xss_clean');
			
			if($this->form_validation->run())
			{
				$data_field=array( 'menu_hover_color'=>$_POST['menu_hover_color']);
				$stat=$this->common_model->update_records('tbl_home_page_settings ',$data_field,'id','1');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Colour Updated Sucessfully..');
					$this->session->set_userdata('error_cls','success');	
				}
				else
				{
					$this->session->set_userdata('error_msg','Error Occurred Try again...');
					$this->session->set_userdata('error_cls','danger');
					
				}
				
			redirect(base_url().'dashboard/home_page/');
			}
		}
		
		
			$this->load->view('dashboard/template',$data);
   }
   
	public function product_details()
	{
		if(isset($_POST['btn_update_account']))
		{
			$this->form_validation->set_rules('product_name','Product Name','required|xss_clean');
			$this->form_validation->set_rules('short_description','Short Description','required|xss_clean');
			$this->form_validation->set_rules('price','Price','required|xss_clean');
			$this->form_validation->set_rules('available_qty','Quantity','required|xss_clean');
			$this->form_validation->set_rules('long_description','Long Description','required|xss_clean');
			$this->form_validation->set_rules('tax','Tax','required|xss_clean');
			$this->form_validation->set_rules('shipping_charges','Shipping Charges','required|xss_clean');
			
			if($this->form_validation->run())
			{
				
				$data_field=array(
					'product_name'=>$_POST['product_name'],
					'short_description'=>$_POST['short_description'],
					'price'=>$_POST['price'],
					'available_qty'=>$_POST['available_qty'],
					'long_description'=>$_POST['long_description'],
					'tax'=>$_POST['tax'],
					'shipping_charges'=>$_POST['shipping_charges']
				);
					
					$q=$this->common_model->update_records('tbl_product_details',$data_field,'id','1');
					if($q)
					{
						$this->session->set_userdata('error_msg','Product Details Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/product_details/');
			}	
		}
		$data['page_header']="Product Details | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='product-details';
		$this->load->view('dashboard/template',$data);
	}
	
	public function product_gallary()
	{
		if(isset($_POST['btn_update_image']))
		{ 	
		
				$config=array('upload_path' => 'assets/dashboard/uploads/image_gal', 'allowed_types' => 'jpg', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("image_gal");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$config["source_image"] = 'assets/dashboard/uploads/image_gal/'.$datas['file_name'];
					$config['new_image'] = 'assets/dashboard/uploads/image_gal/'.$datas['file_name'];
					$config["width"] = 320;
					$config["height"] = 240;

					$this->load->library('image_lib', $config);
					$this->image_lib->fit();
			 
$qq=$this->db->query("select * from tbl_product_gallary WHERE image_name='".$datas['file_name']."'")->row();
if($qq)
{
}else
{
	$data_field=array('image_name'=>$datas['file_name'],'image_description'=>$_POST['image_description']);
	$this->common_model->insert_records('tbl_product_gallary',$data_field);
}
					
					$this->session->set_userdata('error_msg','Product Image Uploaded Sucessfully..');
					$this->session->set_userdata('error_cls','success');
					
				}
				else
				{
					$this->session->set_userdata('error_msg','Unable to upload, Select proper image.');
					$this->session->set_userdata('error_cls','danger');
					
				}
				redirect(base_url().'dashboard/product_gallary/');
		
		}
		if(isset($_GET['ch']))
		{
			$img_path=FCPATH."assets/dashboard/uploads/image_gal/".base64_decode($_GET['nm']);
			unlink($img_path);
			
			$result=$this->common_model->deleteRecords('tbl_product_gallary',base64_decode($_GET['d']));
			if($result)
					{
						$this->session->set_userdata('error_msg','Product Image Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/product_gallary/');
		}
		$data['page_header']="Product Gallary | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='product-gallary';
		$this->load->view('dashboard/template',$data);
	}
	
	public function product_order()
	{
		$data['page_header']="Orders | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='order';
		$this->load->view('dashboard/template',$data);
	}
	
	public function newsletter()
	{
		if(isset($_GET['send']))
		{
		
		$From_email="";$title="";$sub="";$ebody="";$cnt=0;

		$q=$this->db->query("select * from tbl_website_settings where id='1'")->row();
		if($q)
		{
			$From_email=$q->for_newsletter_page;
		}

		$result=$this->db->query("select * from tbl_newsletter_design where id='1'")->row();
		if($result)
		{
			$title=$result->nl_title;
			$sub=$result->nl_subject;
			$ebody=base64_decode($result->nl_design);
		 
			$config = Array(
				'protocol' => 'smtp',
		        'smtp_host' => 'ssl://smtp.googlemail.com',
		        'smtp_port' => 465,
		        'smtp_user' => 'rajendra827@gmail.com',
		        'smtp_pass' => '9185awds',
		        'mailtype'  => 'html', 
		        'charset' => 'utf-8',
		        'wordwrap' => TRUE
	    	);
		    $this->load->library('email', $config);
			$this->email->set_mailtype("html");
		    $this->email->set_newline("\r\n");
 
		    $email_body ='<div>'.$title.'</div>';
		    $this->email->from('rajendra827@gmail.com', 'One Product Shop');
			$result=$this->db->query("select email_id from tbl_newsletter");	
			$list=array();
			if($result->result()>0)
			{
				foreach($result->result() as $row)
				{
					array_push($list,$row->email_id);
				}
				 $cnt=count($list);
			}		    
		   
		    $this->email->to($list);
		    $this->email->bcc($From_email);
		    $this->email->subject($sub);
		    $this->email->message($ebody);

		    $this->email->send();
		    //echo $this->email->print_debugger();
	
/*
 		   $subject = $sub;
		   $message = $ebody;
		   $header = "From:".$From_email." \r\n";
		  // $header = "bcc:admin@creowebtech.com \r\n";
		   $header .= "MIME-Version: 1.0\r\n";
		   $header .= "Content-type: text/html\r\n";	
$result=$this->db->query("select * from tbl_newsletter");	
if($result->result()>0)
{
	foreach($result->result() as $row())	
	{
		  $to = $row->email_id;
		  $retval = mail ($to,$subject,$message,$header);
		  $cnt++;
	}
}
		  
	*/
   }
					 $this->session->set_userdata('error_msg','Email Send To '.$cnt.' subscribers successfully');
					 $this->session->set_userdata('error_cls','success');
					redirect(base_url().'dashboard/newsletter/');
		}
		if(isset($_GET['ch']))
		{
			$result=$this->common_model->deleteRecords('tbl_newsletter',base64_decode($_GET['d']));
			if($result)
					{
						$this->session->set_userdata('error_msg','Subscriber removed Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/newsletter/');
		}
		$data['page_header']="Newsletter  | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='newsletter-subscribe-user';
		$this->load->view('dashboard/template',$data);
	}
	
	public function newsletter_design()
	{
		if(isset($_POST['btn_save_design']))
		{
			$data_field=array('nl_design'=>base64_encode($_POST['nl_design']),'nl_subject'=>$_POST['nl_subject'],'nl_title'=>$_POST['nl_title'],);
			$result=$this->common_model->update_records('tbl_newsletter_design',$data_field,'id','1');
			if($result)
					{
						$this->session->set_userdata('error_msg','Design Updated Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/newsletter_design/');
		}
		$data['page_header']="Newsletter Design | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='newsletter-design';
		$this->load->view('dashboard/template',$data);
	}
	
	public function website_enquery()
	{
		if(isset($_GET['ch']))
		{
			$result=$this->common_model->deleteRecords('tbl_enquery',base64_decode($_GET['id']));
			if($result)
					{
						$this->session->set_userdata('error_msg','Enquery removed Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error Occurred Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					redirect(base_url().'dashboard/website_enquery/');
		}
		$data['page_header']="Website Enquery | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='website-enq';
		$this->load->view('dashboard/template',$data);
	}
	 
	 public function blogs()
	 {	
		$data['page_header']="Website Blogs | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='blogs';
	 	
		if(isset($_GET['pg']))
		{
			$data['page']= base64_decode( $_GET['pg'] );
			
		}
		else
		if(isset($_GET['ch']))
		{
			if($_GET['ch']=='down')
			{
				$stat=$this->common_model->updateStatus('tbl_blogs',base64_decode($_GET['id']),'0');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Blog has been unpublished Sucessfully..');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/blogs');
			}
			else
			if($_GET['ch']=='up')
			{
				$stat=$this->common_model->updateStatus('tbl_blogs',base64_decode($_GET['id']),'1');
				if($stat)
				{
					$this->session->set_userdata('error_msg','Blog has been published Sucessfully..');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/blogs');
			}
			
			else
			if($_GET['ch']=='del')
			{
				$stat=$this->common_model->deleteRecords('tbl_blogs',base64_decode($_GET['id']));
				if($stat)
				{
					$img_path=FCPATH."assets/dashboard/uploads/blogs/".base64_decode($_GET['img_name']);
					unlink($img_path);
			
					$this->session->set_userdata('error_msg','Blog has been removed Sucessfully..');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/blogs');
			}
		}
		if(isset($_POST['btn_update_blog']))
		{
			$this->form_validation->set_rules('title','Blog Title', 'required|xss_clean');
			$this->form_validation->set_rules('short_description','Short Desctiption', 'required|xss_clean');
			$this->form_validation->set_rules('descriptions','Blog Content', 'required|xss_clean');
			$this->form_validation->set_rules('blog_date','Blog Date', 'required|xss_clean');
			$this->form_validation->set_rules('tags','Blog Tags/Keywords', 'required|xss_clean');
			
			if($this->form_validation->run())
			{	
				if(($_FILES['blog_img']['size']>0))
					{
						$config=array('upload_path' => 'assets/dashboard/uploads/blogs', 'allowed_types' => 'jpg', 'overwrite'=> True,);
						$this->upload->initialize($config); // Important
						$this->upload->do_upload("blog_img");
						$datas=$this->upload->data();
						if($datas['file_size'] >0 )
						{
								
								$data_field=array(
									'title'=>$_POST['title'],
									'image_name'=>$datas['file_name'],
									'short_description'=>$_POST['short_description'],
									'descriptions'=>base64_encode($_POST['descriptions']),
									'blog_date'=>$_POST['blog_date'],
									'tags'=>$_POST['tags']
								);
						
								$ins=$this->common_model->update_records('tbl_blogs',$data_field,'id',base64_decode($_POST['id']));
								if($ins)
								{
									$this->session->set_userdata('error_msg','Blog Uploaded successfully');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/blogs');
								}
								else
								{
									$this->session->set_userdata('error_msg','Image Uploaded but Error while uploading details');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/blogs?pg='.base64_encode('blogs-update').'&id='.$_POST['id']);
								}
						}
							 
								$this->session->set_userdata('error_msg','Unable to upload Image, Try again');
								$this->session->set_userdata('error_cls','success');
								redirect(base_url().'dashboard/blogs?pg='.base64_encode('blogs-update').'&id='.$_POST['id']);
							 
					}
					  	
						$data_field=array(
									'title'=>$_POST['title'],
									'short_description'=>$_POST['short_description'],
									'descriptions'=>base64_encode($_POST['descriptions']),
									'blog_date'=>$_POST['blog_date'],
									'tags'=>$_POST['tags']
								);
						
						$ins=$this->common_model->update_records('tbl_blogs',$data_field,'id',base64_decode($_POST['id']));
						if($ins)
								{
									$this->session->set_userdata('error_msg','Blog Uploaded successfully');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/blogs');
								}
								else
								{
									$this->session->set_userdata('error_msg','Error while uploading details');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/blogs?pg='.base64_encode('blogs-update').'&id='.$_POST['id']);
								}
			 	 }
			redirect(base_url().'dashboard/blogs?pg='.base64_encode('blogs-update').'&id='.$_POST['id']);
		}
		if(isset($_POST['btn_create_blog']))
		{
			$this->form_validation->set_rules('title','Blog Title', 'required|xss_clean');
			$this->form_validation->set_rules('short_description','Short Desctiption', 'required|xss_clean');
			$this->form_validation->set_rules('descriptions','Blog Content', 'required|xss_clean');
			$this->form_validation->set_rules('blog_date','Blog Date', 'required|xss_clean');
			$this->form_validation->set_rules('tags','Blog Tags/Keywords', 'required|xss_clean');
			
			 
			if($this->form_validation->run())
			{					
				$config=array('upload_path' => 'assets/dashboard/uploads/blogs', 'allowed_types' => 'jpg', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("blog_img");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$config["source_image"] = 'assets/dashboard/uploads/blogs/'.$datas['file_name'];
					$config['new_image'] = 'assets/dashboard/uploads/blogs/'.$datas['file_name'];
					$config["width"] = 925;
					$config["height"] = 300;

					$this->load->library('image_lib', $config);
					$this->image_lib->fit();
			 
					$qq=$this->db->query("select * from tbl_blogs WHERE image_name='".$datas['file_name']."'")->row();
					if($qq)
					{
					}else
					{
						$data_field=array(
							'title'=>$_POST['title'],
							'image_name'=>$datas['file_name'],
							'short_description'=>$_POST['short_description'],
							'descriptions'=>base64_encode($_POST['descriptions']),
							'blog_date'=>$_POST['blog_date'],
							'tags'=>$_POST['tags']
						);
						
						$this->common_model->insert_records('tbl_blogs',$data_field);
					}
					
					$this->session->set_userdata('error_msg','New Blog Created Sucessfully..');
					$this->session->set_userdata('error_cls','success');
					
					redirect(base_url().'dashboard/blogs');
					
				}
				else
				{
					$this->session->set_userdata('error_msg','Unable to upload, Select Proper Image.');
					$this->session->set_userdata('error_cls','danger');
					
				}
				redirect(base_url().'dashboard/blogs?pg='.base64_encode('blog-create'));
			}
			
		}
		else
		{
			if(isset($_GET['comments']))
			{
				if($_GET['comments']=='view')
				{
					
					if(isset($_GET['Bch']))
					{
						if($_GET['Bch']=="del")
						{
							$ins=$this->common_model->deleteRecords('tbl_blog_comments',base64_decode($_GET['id']));
							if($ins)
							{
								$this->session->set_userdata('error_msg','Comment Removed Successfully');
								$this->session->set_userdata('error_cls','success');
							}
							else
							{
								$this->session->set_userdata('error_msg','Error occurred, Try again...');
								$this->session->set_userdata('error_cls','danger');
							}
							 
						}
						 else
						if($_GET['Bch']=="down")
						{ 
							
							$stat=$this->common_model->updateStatus('tbl_blog_comments',base64_decode($_GET['id']),'0');
							if($stat)
							{
								$this->session->set_userdata('error_msg','Comment has been unpublished Sucessfully..');
								$this->session->set_userdata('error_cls','success');
							}
							else
							{
								$this->session->set_userdata('error_msg','Error occurred, Try again');
								$this->session->set_userdata('error_cls','danger');
							}
							 
						}
						else
						if($_GET['Bch']=="up")
						{ 
							$stat=$this->common_model->updateStatus('tbl_blog_comments',base64_decode($_GET['id']),'1');
							if($stat)
							{
								$this->session->set_userdata('error_msg','Comment has been unpublished Sucessfully..');
								$this->session->set_userdata('error_cls','success');
							}
							else
							{
								$this->session->set_userdata('error_msg','Error occurred, Try again');
								$this->session->set_userdata('error_cls','danger');
							}
							 
						}
						
						redirect(base_url().'dashboard/blogs?comments=view&blog_id='.base64_encode(base64_encode($_GET['id'])));
						
					}
					$data['page']='blogs-comments';
					
					 
				}
			}
		}
			
		
		$this->load->view('dashboard/template',$data);
		
	 }
	 
	 
	 public function news()
	 {
	 	$data['page_header']="Website News | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='news';
	 	
	 	if(isset($_GET['pg']))
		{
			$data['page']= base64_decode( $_GET['pg'] );
		}
		
		if(isset($_POST['btn_create_news']))
		{
			$this->form_validation->set_rules('title','News Title', 'required|xss_clean');
			$this->form_validation->set_rules('description','Desctiption', 'required|xss_clean');
			$this->form_validation->set_rules('news_date','News Date', 'required|xss_clean');
			
			 
			if($this->form_validation->run())
			{					
				$config=array('upload_path' => 'assets/dashboard/uploads/news', 'allowed_types' => 'jpg', 'overwrite'=> True,);
				$this->upload->initialize($config); // Important
				$this->upload->do_upload("news_img");
				$datas=($this->upload->data());
				//echo "<br/>";
				
				if($datas['file_size'] >0 )
				{
					$config["source_image"] = 'assets/dashboard/uploads/news/'.$datas['file_name'];
					$config['new_image'] = 'assets/dashboard/uploads/news/'.$datas['file_name'];
					$config["width"] = 150;
					$config["height"] = 150;

					$this->load->library('image_lib', $config);
					$this->image_lib->fit();
			 
						$data_field=array(
							'title'=>$_POST['title'],
							'image_name'=>$datas['file_name'],
							'description'=>base64_encode($_POST['description']),
							'news_date'=>$_POST['news_date']
						);
						
						$this->common_model->insert_records('tbl_news',$data_field);
					 
					
					$this->session->set_userdata('error_msg','News Created Sucessfully..');
					$this->session->set_userdata('error_cls','success');
					
					redirect(base_url().'dashboard/news');
					
				}
				else
				{
					$this->session->set_userdata('error_msg','Unable to upload, Select Proper Image.');
					$this->session->set_userdata('error_cls','danger');
					
				}
				redirect(base_url().'dashboard/news?pg='.base64_encode('blog-create'));
			}
			
		
		}
		else
		if(isset($_POST['btn_update_news']))
		{
			
			$this->form_validation->set_rules('title','News Title', 'required|xss_clean');
			$this->form_validation->set_rules('description','Desctiption', 'required|xss_clean');
			$this->form_validation->set_rules('news_date','News Date', 'required|xss_clean');
				
			if($this->form_validation->run())
			{	
				if(($_FILES['news_img']['size']>0))
					{
						$config=array('upload_path' => 'assets/dashboard/uploads/news', 'allowed_types' => 'jpg', 'overwrite'=> True,);
						$this->upload->initialize($config); // Important
						$this->upload->do_upload("news_img");
						$datas=$this->upload->data();
						
						if($datas['file_size'] >0 )
						{								
								$data_field=array(
									'title'=>$_POST['title'],
									'image_name'=>$datas['file_name'],
									'description'=>base64_decode($_POST['description']),
									'news_date'=>$_POST['news_date']
								);
						
								$ins=$this->common_model->update_records('tbl_news',$data_field,'id',base64_decode($_POST['id']));
								if($ins)
								{
									$this->session->set_userdata('error_msg','News Uploaded successfully');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/news');
								}
								else
								{
									$this->session->set_userdata('error_msg','Image Uploaded but Error while uploading details');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/news?pg='.base64_encode('blogs-update').'&id='.$_POST['id']);
								}
						}
							 
								$this->session->set_userdata('error_msg','Unable to upload Image, Try again');
								$this->session->set_userdata('error_cls','success');
								redirect(base_url().'dashboard/news?pg='.base64_encode('news-update').'&id='.$_POST['id']);
							 
					}
					  	
						$data_field=array(
									'title'=>$_POST['title'],
									'description'=>base64_encode($_POST['description']),
									'news_date'=>$_POST['news_date'],
								);
						
						$ins=$this->common_model->update_records('tbl_news',$data_field,'id',base64_decode($_POST['id']));
						if($ins)
								{
									$this->session->set_userdata('error_msg','News Uploaded successfully');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/news');
								}
								else
								{
									$this->session->set_userdata('error_msg','Error while uploading details');
									$this->session->set_userdata('error_cls','success');
									redirect(base_url().'dashboard/news?pg='.base64_encode('news-update').'&id='.$_POST['id']);
								}
			 	 }
			redirect(base_url().'dashboard/news?pg='.base64_encode('news-update').'&id='.$_POST['id']);
		
		}
		else
			if(isset($_GET['ch']))
			{
				if($_GET['ch']=="del")
				{
					$img_path=FCPATH.'assets/dashboard/uploads/news/'.base64_decode($_GET['img_name']);
					unlink($img_path);
					$ins=$this->common_model->deleteRecords('tbl_news',base64_decode($_GET['id']));
					if($ins)
					{
						$this->session->set_userdata('error_msg','Comment Removed Successfully');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
				}else
				if($_GET['ch']=="down")
				{ 
					$stat=$this->common_model->updateStatus('tbl_news',base64_decode($_GET['id']),'0');
					if($stat)
					{
						$this->session->set_userdata('error_msg','News has been unpublished Sucessfully..');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again');
						$this->session->set_userdata('error_cls','danger');
					}
							 
				}
				else
				if($_GET['ch']=="up")
				{ 
						$stat=$this->common_model->updateStatus('tbl_news',base64_decode($_GET['id']),'1');
						if($stat)
						{
							$this->session->set_userdata('error_msg','News has been unpublished Sucessfully..');
							$this->session->set_userdata('error_cls','success');
						}
						else
						{
							$this->session->set_userdata('error_msg','Error occurred, Try again');
							$this->session->set_userdata('error_cls','danger');
						}
				}
				
				redirect(base_url().'dashboard/news');
			}
		
		
	 	$this->load->view('dashboard/template',$data);
	 }
	 
	  
	 public function videos()
	 {
	 	if(isset($_POST['btn_submit_link']))
	 	{
	 		$this->form_validation->set_rules('video_url','Video Link', 'required');
	 		if($this->form_validation->run())
	 		{
				$url = $_POST['video_url'];
				$parts = parse_url($url);
				parse_str($parts['query'], $query);
				 
				$data_fiields=array(
					'youtube_link'=>$query['v']
				);
				
				$ins=$this->common_model->update_records('tbl_website_settings',$data_fiields,'id','1');
				if($ins)
				{
					$this->session->set_userdata('error_msg','Website url uploaded');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, try again later..');
					$this->session->set_userdata('error_cls','danger');
				}
			}
	 		
			
			
		}
	 	
	 	if(isset($_POST['btn_submit_video']))
		{	
		 
				$file				= 'userfile';
				$config['upload_path']		= 'assets/dashboard/uploads/';
				$config['allowed_types'] 	= 'MP4|Mp4|mov|mpeg|mp4|avi|mp3';
				$config['max_size']		= '500000';
				$config['overwrite']		= 'true';
				$config['file_name']		= 'video';
				
$this->upload->initialize($config);
$this->load->library('upload', $config);
if(!$this->upload->do_upload($file))
{
	$this->session->set_userdata('error_msg','Unable to upload, Select Proper Video.');
	$this->session->set_userdata('error_cls','danger');
}
else
{
	$this->session->set_userdata('error_msg','Website Video Updated Sucessfully..');
	$this->session->set_userdata('error_cls','success');
}
				 
				redirect(base_url().'dashboard/videos/');
		
			}
			
	 	$data['page_header']="Website Videos | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='videos';
	 	
	 	$this->load->view('dashboard/template',$data);
	 }
	 
	 
	 
	 
	 public function events()
	 {
	 	$data['page_header']="Website Events | " . $this->website_name;
		$data['Website_name']=$this->website_name;
	 	$data['page']='events-manage';
	 	if(isset($_GET['pg']))
		{
			$data['page']= base64_decode( $_GET['pg'] );
			
		}
		
	 	if(isset($_POST['btn_create_events']))
	 	{
			$this->form_validation->set_rules('title','Title','required|xss_Clean');
			$this->form_validation->set_rules('short_description','Short Description','required|xss_Clean');
			$this->form_validation->set_rules('description','Description','required|xss_Clean');
			$this->form_validation->set_rules('tyme','Event Time','required|xss_Clean');
			$this->form_validation->set_rules('address','Event Address','required|xss_Clean');
			$this->form_validation->set_rules('day','Event Day','required|xss_Clean');
			$this->form_validation->set_rules('location','Event Location','required|xss_Clean');
			
			$this->form_validation->set_rules('dd','DD','required|xss_Clean');
			$this->form_validation->set_rules('mm','MM','required|xss_Clean');
			$this->form_validation->set_rules('yyyy','YYYY','required|xss_Clean');
			
			if($this->form_validation->run())
			{
				$data_fields=array(
					'dd'=>$_POST['dd'],
					'mm'=>$_POST['mm'],
					'yyyy'=>$_POST['yyyy'],
					'title'=>$_POST['title'],
					'day'=>$_POST['day'],
					'location'=>$_POST['location'],
					'short_description'=>$_POST['short_description'],
					'description'=>$_POST['description'],
					'tyme'=>$_POST['tyme'],
					'address'=>$_POST['address'],
				);
				
				$ins=$this->common_model->insert_records('tbl_events',$data_fields);
				if($ins)
				{
					$this->session->set_userdata('error_msg','Event Created successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/events');
			}
			
		}
		else
		if(isset($_POST['btn_update_events']))
		{
				$this->form_validation->set_rules('title','Title','required|xss_Clean');
				$this->form_validation->set_rules('short_description','Short Description','required|xss_Clean');
				$this->form_validation->set_rules('description','Description','required|xss_Clean');
				$this->form_validation->set_rules('tyme','Event Time','required|xss_Clean');
				$this->form_validation->set_rules('address','Event Address','required|xss_Clean');
				$this->form_validation->set_rules('day','Event Day','required|xss_Clean');
				$this->form_validation->set_rules('location','Event Location','required|xss_Clean');
				$this->form_validation->set_rules('dd','DD','required|xss_Clean');
				$this->form_validation->set_rules('mm','MM','required|xss_Clean');
				$this->form_validation->set_rules('yyyy','YYYY','required|xss_Clean');
			
				if($this->form_validation->run())
				{
					$data_fields=array(
					'dd'=>$_POST['dd'],
					'mm'=>$_POST['mm'],
					'yyyy'=>$_POST['yyyy'],
					'title'=>$_POST['title'],
					'day'=>$_POST['day'],
					'location'=>$_POST['location'],
					'short_description'=>$_POST['short_description'],
					'description'=>$_POST['description'],
					'tyme'=>$_POST['tyme'],
					'address'=>$_POST['address'],
				);
				
				$ins=$this->common_model->update_records('tbl_events',$data_fields,'id',base64_decode($_POST['id']));
				if($ins)
				{
					$this->session->set_userdata('error_msg','Event Updated successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/events');
				}
		}
		else
		if(isset($_GET['ch']))
		{
			if($_GET['ch']=='down')
			{
				$ins=$this->common_model->updateStatus('tbl_events',base64_decode($_GET['id']),0);
				if($ins)
				{
					$this->session->set_userdata('error_msg','Event status change successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
			}
			else
			if($_GET['ch']=='up')
			{
				$ins=$this->common_model->updateStatus('tbl_events',base64_decode($_GET['id']),1);
				if($ins)
				{
					$this->session->set_userdata('error_msg','Event status change successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
			}
			else
			if($_GET['ch']=='del')
			{
				$ins=$this->common_model->deleteRecords('tbl_events',base64_decode($_GET['id']));
				if($ins)
				{
					$this->session->set_userdata('error_msg','Event deleted successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
			}
			
			redirect(base_url().'dashboard/events');
		}
	 	$this->load->view('dashboard/template',$data);
	 }
	 
	 public function schedules()
	 {
	 		$data['page_header']="Schedule Appointment | " . $this->website_name;
			$data['Website_name']=$this->website_name;
		 	$data['page']='schedule-manage';
	 
		 	if(isset($_GET['pg']))
			{
				$data['page']= base64_decode( $_GET['pg'] );
			}
			
			if(isset($_POST['btn_create_schedule']))
			{
				$this->form_validation->set_rules('title','Schedule','required|xss_clean');
				$this->form_validation->set_rules('start_date','Start Date','required|xss_clean');
				$this->form_validation->set_rules('end_date','End Date','required|xss_clean');
				$this->form_validation->set_rules('start_time','Start Time','required|xss_clean');
				$this->form_validation->set_rules('end_time','End Time','required|xss_clean');
				$this->form_validation->set_rules('bg_colors','Event Color','required|xss_clean');
				$this->form_validation->set_rules('allday','Event Type','required|xss_clean');
				$this->form_validation->set_rules('is_available','Is Available','required|xss_clean');
				if($this->form_validation->run())
				{
					$data_fields=array(
						'title'=>$_POST['title'],
						'start_date'=>$_POST['start_date'],
						'end_date'=>$_POST['end_date'],
						'start_time'=>$_POST['start_time'],
						'end_time'=>$_POST['end_time'],
						'bg_colors'=>$_POST['bg_colors'],
						'allday'=>$_POST['allday'],
						'is_available'=>$_POST['is_available']
					);
					
					$ins=$this->common_model->insert_records('tbl_schedule',$data_fields);
					if($ins)
					{
						$this->session->set_userdata('error_msg','Schedule Created successfully');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					
					redirect(base_url().'dashboard/schedules');
				}
				
				
			}
			else
			if(isset($_POST['btn_update_schedule']))
			{
				
				$this->form_validation->set_rules('title','Schedule','required|xss_clean');
				$this->form_validation->set_rules('start_date','Start Date','required|xss_clean');
				$this->form_validation->set_rules('end_date','End Date','required|xss_clean');
				$this->form_validation->set_rules('start_time','Start Time','required|xss_clean');
				$this->form_validation->set_rules('end_time','End Time','required|xss_clean');
				$this->form_validation->set_rules('bg_colors','Event Color','required|xss_clean');
				$this->form_validation->set_rules('allday','Event Type','required|xss_clean');
				$this->form_validation->set_rules('is_available','Is Available','required|xss_clean');
				if($this->form_validation->run())
				{
					$data_fields=array(
						'title'=>$_POST['title'],
						'start_date'=>$_POST['start_date'],
						'end_date'=>$_POST['end_date'],
						'start_time'=>$_POST['start_time'],
						'end_time'=>$_POST['end_time'],
						'bg_colors'=>$_POST['bg_colors'],
						'allday'=>$_POST['allday'],
						'is_available'=>$_POST['is_available']
					);
					
					$ins=$this->common_model->update_records('tbl_schedule',$data_fields,'id',base64_decode($_POST['id']));
					if($ins)
					{
						$this->session->set_userdata('error_msg','Schedule update successfully');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
					
					redirect(base_url().'dashboard/schedules?pg='.base64_encode('schedule-manage1'));
				}
			}
			else
			if(isset($_GET['ch']))
			{
				if($_GET['ch']=="del")
				{
					 
					$ins=$this->common_model->deleteRecords('tbl_schedule',base64_decode($_GET['id']));
					if($ins)
					{
						$this->session->set_userdata('error_msg','Schedule deleted successfully');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
				}
				else if($_GET['ch']=='down')
				{
					$ins=$this->common_model->updateStatus('tbl_schedule',base64_decode($_GET['id']),0);
					if($ins)
					{
						$this->session->set_userdata('error_msg','Schedule status change successfully');
						$this->session->set_userdata('error_cls','success');
					}
					else
					{
						$this->session->set_userdata('error_msg','Error occurred, Try again...');
						$this->session->set_userdata('error_cls','danger');
					}
				}
				else
			if($_GET['ch']=='up')
			{
				$ins=$this->common_model->updateStatus('tbl_schedule',base64_decode($_GET['id']),1);
				if($ins)
				{
					$this->session->set_userdata('error_msg','Schedule status change successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
			}
				redirect(base_url().'dashboard/schedules?pg='.base64_encode('schedule-manage1'));
				
			}
			if(isset($_POST['btn_change_stat']))
			{
				echo $_POST['display_stat'];
				$data_val=array('display_schedule'=>$_POST['display_stat']);
				$ins=$this->common_model->update_records('tbl_website_settings',$data_val,'id','1');
				if($ins)
				{
					$this->session->set_userdata('error_msg','Display status change successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
				redirect(base_url().'dashboard/schedules');
			}
			
			
	 		$this->load->view('dashboard/template',$data);
	 }
	 
	 public function reservation()
	 {
	 	
	 	
	 	if(isset($_GET['ch']))
	 	{
			if($_GET['ch']=='del')
			{
				$ins=$this->common_model->deleteRecords('tbl_booking_appointment',base64_decode($_GET['id']));
				if($ins)
				{
					$this->session->set_userdata('error_msg','Booking deleted successfully');
					$this->session->set_userdata('error_cls','success');
				}
				else
				{
					$this->session->set_userdata('error_msg','Error occurred, Try again...');
					$this->session->set_userdata('error_cls','danger');
				}
			}
			else
			if($_GET['ch']=='confirm')
			{
				$emailid=$this->db->query("select for_support as emailid from tbl_website_settings where id = '1'")->row();
				if($emailid)
				{
					
					$msg='
<div>
<table width="650" border="0" align="center" cellspacing="0" cellpadding="0" style="border:1px solid #c5c5c5;padding:20px;width:650px;margin:20px auto">
	<tbody><tr>
		<td>
			<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
				<tbody><tr style="border:0px;background-color:#ffdc34">
					<td align="center" valign="top">
					<a href="'.base_url().'">
					<img src="'.base_url().'assets/dashboard/uploads/logo.png">
					</a></td>
				</tr>
			</tbody></table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center">
				<tbody><tr>
					<td align="left" valign="top" style="padding:0 30px;font-family:Arial,Helvetica,sans-serif;font-size:15px;line-height:24px;color:#191b1f;text-align:left">
						<h3>Hello '.strtoupper(base64_decode($_GET['nm'])).',</h3>
						<p></p><p>Congratulations !!! <span class="il">Your</span> <span class="il">appointment</span> has been created successfully</p>

<p><span class="il">Your</span> email is <a href="mailto:'.base64_decode($_GET['email']).'" target="_blank">'.base64_decode($_GET['email']).'</a></p>

<p>Please click <a href="'.base_url().'site/confirm_booking?booking_id='.base64_encode(base64_encode(base64_encode($_GET['id']))).'" target="_blank">here</a> to confirm <span class="il">your</span> <span class="il">booking</span></p><p></p>
 </td>
				</tr>
			</tbody></table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="border:1px solid #d7d7d7;background:#e9e9e9;padding:10px;margin:20px 0">
			</table>
			<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="border:1px solid #d7d7d7;background:#f3f3f3;padding:10px;margin-bottom:20px">
				<tbody><tr>
					<td align="left" valign="middle" style="font-size:11px;font-family:Arial,Helvetica,sans-serif;color:#666666;font-style:italic;text-align:left"> Copyright © <u></u> '.base_url().', All rights reserved. </td>
				</tr>
			</tbody></table>
		</td>
	</tr>
</tbody></table><div class="yj6qo"></div><div class="adL">
</div></div>';



					$config = Array(
						'protocol' => 'smtp',
				        'smtp_host' => 'ssl://smtp.googlemail.com',
				        'smtp_port' => 465,
				        'smtp_user' => 'rajendra827@gmail.com',
				        'smtp_pass' => '9185awds',
				        'mailtype'  => 'html', 
				        'charset' => 'utf-8',
				        'wordwrap' => TRUE
			    	);
				    $this->load->library('email', $config);
					$this->email->set_mailtype("html");
				    $this->email->set_newline("\r\n");
		 
				    $this->email->from('rajendra827@gmail.com', $this->website_name);
				    
				    $list = array(base64_decode($_GET['email']));
				
				    $this->email->to($list);
				    $this->email->subject('Appointment Confirmation');
				    $this->email->message($msg);

				    $stat=$this->email->send();
				    //echo $this->email->print_debugger();
					if($stat==1)
					{
						$data_fiels=array(
							'status'=>'sent_to_user'
						)	;
						
						$ins=$this->common_model->update_records('tbl_booking_appointment',$data_fiels,'id',base64_decode($_GET['id']));
						if($ins)
						{
							$this->session->set_userdata('error_msg','Confirmation EMail Send Successfully');
							$this->session->set_userdata('error_cls','success');
						}
						else
						{
							$this->session->set_userdata('error_msg','Error occurred, Try again...');
							$this->session->set_userdata('error_cls','danger');
						}
					}


 
	
	/*
	 	   $to = $emailid->emailid;
		   $subject = 'Appointment Confirmation';
		   $message = "";
		   $header = "From:".$emailid->emailid." \r\n";
		   $header .= "MIME-Version: 1.0\r\n";
		   $header .= "Content-type: text/html\r\n";
		   $retval = mail ($to,$subject,$message,$header);
	 */
	 
	  
				}
				
			}
			redirect(base_url().'dashboard/reservation');
		}
	 		$data['page_header']="Manage Reservation | " . $this->website_name;
			$data['Website_name']=$this->website_name;
		 	$data['page']='reservation-manage';
		 	$this->load->view('dashboard/template',$data);
	 }
}
?>