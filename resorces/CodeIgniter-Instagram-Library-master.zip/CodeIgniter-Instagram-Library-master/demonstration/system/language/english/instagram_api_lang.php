<?php

/*
|--------------------------------------------------------------------------
| Instagram
|--------------------------------------------------------------------------
|
| Instagram client details
|
*/

$lang['client_name']	= 'Ian Luckraft Demonstration';
$lang['client_id']		= '3c9fdeec2a194598862328710a5941f6';
$lang['client_secret']	= '2036e1e3e72d49019ad151de02aa4dad';
$lang['callback_url']	= 'http://ianluckraft.co.uk/demonstrations/instagram-library/authorize/get_code/';
$lang['website']		= 'http://ianluckraft.co.uk';
$lang['description']	= 'For use in ianluckraft.co.uk and testing development including a codeigniter library.';