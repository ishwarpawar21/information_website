<?php

/*
|--------------------------------------------------------------------------
| Instagram
|--------------------------------------------------------------------------
|
| Instagram client details
|
*/

$config['instagram_client_name']	= '';
$config['instagram_client_id']		= '';
$config['instagram_client_secret']	= '';
$config['instagram_callback_url']	= '';
$config['instagram_website']		= '';
$config['instagram_description']	= '';