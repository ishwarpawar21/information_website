<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['twitter_consumer_token']		= 'your_consumer_token';
$config['twitter_consumer_secret']		= 'your_consumer_token_secret';
$config['twitter_access_token']			= 'your_access_token'; // Optional
$config['twitter_access_secret']		= 'your_access_token_secret'; // Optional

/* End of file twitter.php */
/* Location: ./application/config/twitter.php */